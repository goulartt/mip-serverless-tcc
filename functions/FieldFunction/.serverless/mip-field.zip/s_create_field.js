var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'goulartt',
applicationName: 'myapp',
appUid: 'hpH3ZmSjbKYR50XpnG',
tenantUid: 'dGnHRDpC28y96MHDsR',
deploymentUid: '66bc1371-4543-497f-9c87-47e42da84d86',
serviceName: 'mip-field',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'mip-field-dev-create-field', timeout: 6}
try {
  const userHandler = require('./field.js')
  module.exports.handler = serverlessSDK.handler(userHandler.create, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
