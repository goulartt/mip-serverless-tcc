var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'goulartt',
applicationName: 'myapp',
appUid: 'hpH3ZmSjbKYR50XpnG',
tenantUid: 'dGnHRDpC28y96MHDsR',
deploymentUid: '587f99e3-4200-4935-bdd0-14a68a98551d',
serviceName: 'fieldnodelambdafunction',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'fieldnodelambdafunction-dev-create-field', timeout: 6}
try {
  const userHandler = require('./field.js')
  module.exports.handler = serverlessSDK.handler(userHandler.create, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
